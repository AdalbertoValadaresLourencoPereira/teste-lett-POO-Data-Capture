package br.com.lettTecnologia.mamiferos;

import br.com.lettTecnologia.animais.VidaAnimal;

public class Morcego extends Mamiferos implements VidaAnimal {

	/**
	 * @author Adalberto Valadares
	 * 
	 *         Classe filha de Mamiferos --> Animais, que herda os atributos de
	 *         Animais por meio de heran�a. possui os metodos amamentar() e
	 *         emitirSom(), voar() todos do tipo void. Assim como o metodo
	 *         dadosoMorcego(), que realiza a impressao dos dados do objeto, Dados
	 *         impressos..: Idade Tamanho, corDoPelo, E o conteudo dos metodos
	 *         respectivos. *
	 * 
	 */

	public Morcego() {
		super();
	}

	@Override
	public void amamentar() {
		System.out.println("O morcego est� amamentando!");

	}

	public void voar() {

		System.out.println("O morcego est� voando a 5 mt de altura, altura m�xima de 10 mts.!");
	}

	@Override
	public void emitirSom() {
		System.out.println("O morcego est� emitindo um farfalho!");

	}

	public void dadosMorcego() {

		String string = null;

		if (this.getIdade() <= 1) {
			string = " ano";
		} else {
			string = " anos";
		}

		System.out.println("\n");
		System.out.println("***Novo animal cadastrado com sucesso!***");
		System.out.println("\n");
		System.out.println("O  morcego tem " + this.getIdade() + string);
		System.out.println("O tamanho do morcego � " + this.getTamanho() + " cent�metros.");
		System.out.println("A cor do morcego � " + this.getCorDoPelo() + ".");
	}

}
