package br.com.lettTecnologia.mamiferos;

import br.com.lettTecnologia.animais.Animais;

public abstract class Mamiferos extends Animais {

	/**
	 * @author Adalberto Valadares
	 * 
	 *         Subclasse de Animais, que ser� superclasse dos das classes, Vaca e
	 *         Morcego.. Possui o atributo corDoPelo do tipo String para diferenciar
	 *         as stancias de Morcego e Vacas respectivamente. Possui os metodos
	 *         acessores e abstrato Amamentar do tipo void.
	 */

	private String corDoPelo;

	public Mamiferos() {
		super();
		this.corDoPelo = corDoPelo;
	}

	public String getCorDoPelo() {
		return corDoPelo;
	}

	public void setCorDoPelo(String corDoPelo) {
		this.corDoPelo = corDoPelo;
	}

	public abstract void amamentar();

}
