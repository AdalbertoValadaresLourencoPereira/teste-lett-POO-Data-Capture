package br.com.lettTecnologia.mamiferos;

import br.com.lettTecnologia.animais.VidaAnimal;

public class Vaca extends Mamiferos implements VidaAnimal {

	/**
	 * @author Adalberto Valadares
	 * 
	 *         Classe filha de Mamiferos --> Animais, que herda os atributos de
	 *         Animais por meio de heran�a. possui os metodos amamentar() do tipo
	 *         void, e emitirSom(). Assim como o metodo dadosVaca(), que realiza a
	 *         impressao dos dados do objeto,
	 * 
	 *         Dados impressos..: Idade Tamanho, corDoPelo, E o conteudo dos metodos
	 *         respectivos. *
	 * 
	 */

	public Vaca() {
		super();

	}

	@Override
	public void amamentar() {
		System.out.println("A Vaca est� amamentando!");

	}

	@Override
	public void emitirSom() {
		System.out.println("A Vaca est� emitindo um mugido.!");

	}

	public void dadosVaca() {

		String string = null;

		if (this.getIdade() <= 1) {
			string = " ano";
		} else {
			string = " anos";
		}

		System.out.println("\n");
		System.out.println("*** Novo animal cadastrado com sucesso! ***");
		System.out.println("\n");
		System.out.println("A Vaca tem " + this.getIdade() + string);
		System.out.println("O tamanho da Vaca � " + this.getTamanho() + " cent�metros.");
		System.out.println("A cor da Vaca � " + this.getCorDoPelo() + ".");
	}

}
