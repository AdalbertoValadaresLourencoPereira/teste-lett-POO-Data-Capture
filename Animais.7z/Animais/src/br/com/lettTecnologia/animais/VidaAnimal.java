package br.com.lettTecnologia.animais;

public interface VidaAnimal {

	/**
	 * @author Adalberto Valadares
	 * 
	 *         Interface com m�todo abstrato emitir som, que ser� implementado pelas
	 *         instancias do das classes Pato, Galinha, Morcego e Vaca.
	 *         
	 */
	
	
	public abstract void emitirSom();

}
