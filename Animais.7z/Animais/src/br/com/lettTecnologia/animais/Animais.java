package br.com.lettTecnologia.animais;

public abstract class Animais {

	private int idade;
	private double tamanho;

	/**
	 * @author Adalberto Valadares
	 * 
	 *         Super classe sistema. Possui os atributos idade do tipo integer e
	 *         tamanho do tipo double, ambos privados, que ser�o herdadas pelas
	 *         classes Aves, Mamiferos e suas respectivas classes filhas.
	 *         M�todos acessores.
	 */

	public Animais() {
		this.idade = idade;
		this.tamanho = tamanho;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double getTamanho() {
		return tamanho;
	}

	public void setTamanho(double tamanho) {
		this.tamanho = tamanho;
	}

}