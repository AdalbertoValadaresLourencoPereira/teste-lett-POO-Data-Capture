package br.com.lettTecnologia.sistema;

import java.awt.Menu;
import java.io.InputStream;
import java.util.Scanner;

import br.com.lettTecnologia.aves.Galinha;
import br.com.lettTecnologia.aves.Pato;
import br.com.lettTecnologia.mamiferos.Morcego;
import br.com.lettTecnologia.mamiferos.Vaca;

public class TesteAnimaisFazenda {

	public static void main(String[] args) {
	
		
		/**
		 * @author Adalberto Valadares
		 * Classe com m�todo main, possui 1 objeto da classe Sistema e outro Scanner. Responsaveis pela execu��o do sistema em si. 
		 * Ao iniciar, � solicitado que o usuario confirme que deseje cadastrar os animais(op ==1) , caso contrario, � encerrado.
		 * 
		 */
		int op = 0;

		Sistemas menu = new Sistemas();
		Scanner input = new Scanner(System.in);

		System.out.println("======================== Bem Vindo(a) ao Sistema Para Cadastro de Animais ========================");
		System.out.println("Digite 1 para Iniciar..: ");
		System.out.println("\n1 - Cadastro de Animais.");
		op = input.nextInt();

		switch (op) {

		case 1:
			menu.ApresentarMenu();
		break;

		default:
			System.out.println("Op��o inv�lida.");
			break;
		}

	}

}
