package br.com.lettTecnologia.sistema;

import java.io.IOException;
import java.util.Scanner;

import br.com.lettTecnologia.aves.Aves;
import br.com.lettTecnologia.aves.Galinha;
import br.com.lettTecnologia.aves.Pato;
import br.com.lettTecnologia.mamiferos.Morcego;
import br.com.lettTecnologia.mamiferos.Vaca;

public class Sistemas {

	/**
	 * @author Adalberto Valadares
	 * 
	 *         Classe solicita ao usuario uma op��o sobre qual animal deseja
	 *         cadastro, por meio de um objeto da classe Scanner, � feito a leitura
	 *         desta op��o( de 1 a 4), por meio de um switch, � feito a decisao de
	 *         qual animal cadastrar. Ap�s a escolha, solicita ao usu�rio que
	 *         forne�a os dados pertinentes ao objeto conforme abaixo *
	 * 
	 *         idade tamanho
	 * 
	 *         para Aves.: cor da pena
	 * 
	 *         para Mamiferos.: cor do Pelo
	 * 
	 *         Ap�s a leitura dos dados, � realizada a chamada do metodo de cada
	 *         objeto, e perguntando se deseja realizar um novo cadastro, em caso
	 *         afirmativo, solicia os dados conforme o objeto escolhido, caso
	 *         contrario encessa o sistema.
	 * 
	 */

	Scanner input = new Scanner(System.in);
	private int escolhaAnimal, op;

	public void ApresentarMenu() {

		System.out.println("\n*** Sistema de cadastro de animais da Fazenda!!! ***");
		System.out.println("***** Selecione um novo animal. *****\n");

		System.out.println(
				"O que deseja cadastrar? " + "\n1 - Galinha." + "\n2 - Pato." + "\n3 - Gado." + "\n4 - Morcego.");
		escolhaAnimal = input.nextInt();

		switch (escolhaAnimal) {

		case 1:
			cadastrarGalinha();
			break;

		case 2:
			cadastrarPato();
			break;

		case 3:
			cadastrarVaca();
			break;

		case 4:
			cadastrarMorcego();
			break;

		default:
			System.out.println("Op��o Inv�lida.");
			break;

		}

		System.out.println("\nDeseja cadastrar um novo animal ?\n1 - Sim.\n0 - N�o");
		op = input.nextInt();

		if (op == 1) {

			ApresentarMenu();
		} else {
			System.out.println("\n************* Encerrando o sistema*************");

			System.exit(0);
		}
	}

	public void cadastrarGalinha() {

		System.out.println("Cadastro de Galinha.\nInforme os dados por favor: ");

		Galinha galinha = new Galinha();
		System.out.println("Qual a idade da galinha(em anos)? ");
		galinha.setIdade(input.nextInt());
		System.out.println("Informe seu tamanho (em cent�metros,)? ");
		galinha.setTamanho(input.nextDouble());
		System.out.println("Qual cor de suas penas? ");
		galinha.setCorDaPena(input.next());

		galinha.dadosGalinha();
		galinha.emitirSom();
		galinha.botarOvo();

		System.out.println("\n### Fim do cadastro! ###");
	}

	public void cadastrarPato() {

		System.out.println("Cadastro de pato.\nInforme os dados por favor: ");

		Pato pato = new Pato();
		System.out.println("Qual a idade do pato?");
		pato.setIdade(input.nextInt());
		System.out.println("Qual � o seu tamanho (em cent�metros)? ");
		pato.setTamanho(input.nextDouble());
		System.out.println("Qual a cor de suas penas?");
		pato.setCorDaPena(input.next());

		pato.dadosPato();
		pato.emitirSom();
		pato.botarOvo();
		pato.voar();

		System.out.println("\n### Fim do cadastro! ###");

	}

	public void cadastrarMorcego() {

		System.out.println("Cadastro de Morcego.\nInforme os dados por favor: ");

		Morcego morcego = new Morcego();

		System.out.println("Quantos a idade do Morcego(em anos)? ");
		morcego.setIdade(input.nextInt());
		System.out.println("Qual � o seu tamanho (em cent�metros)? ");
		morcego.setTamanho(input.nextDouble());
		System.out.println("Qual a cor do seu pelo? ");
		morcego.setCorDoPelo(input.next());

		morcego.dadosMorcego();
		morcego.emitirSom();
		morcego.amamentar();

		System.out.println("\n### Fim do cadastro! ###");

	}

	public void cadastrarVaca() {

		System.out.println("Cadastro de Vaca.\nInforme os dados por favor: ");

		Vaca vaca = new Vaca();
		System.out.println("Quantos a idade da vaca(em anos)? ");
		vaca.setIdade(input.nextInt());
		System.out.println("Qual � o seu tamanho (em metros)? ");
		vaca.setTamanho(input.nextDouble());
		System.out.println("Qual a cor do seu pelo? ");
		vaca.setCorDoPelo(input.next());

		vaca.dadosVaca();

		vaca.emitirSom();
		vaca.amamentar();

		System.out.println("\n### Fim do cadastro! ###");

	}

}
