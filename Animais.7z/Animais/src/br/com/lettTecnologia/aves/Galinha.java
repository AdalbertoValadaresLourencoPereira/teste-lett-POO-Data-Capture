package br.com.lettTecnologia.aves;

import br.com.lettTecnologia.animais.VidaAnimal;

public class Galinha extends Aves implements VidaAnimal {

	/**
	 * @author Adalberto Valadares
	 * 
	 *         Classe filha de Aves --> Animais, que herda os atributos de Animais
	 *         por meio de heran�a. possui os metodos botarOvo() do tipo void, e
	 *         emitirSom(). Assim como o metodo dadosGalinha(), que realiza a
	 *         impressao dos dados do objeto,
	 * 
	 *         Dados impressos..: Idade, Tamanho, corDaPena, E o conteudo dos
	 *         metodos respectivos. *
	 * 
	 */

	public Galinha() {
		super();

	}

	@Override
	public void botarOvo() {
		System.out.println("A galinha botou um ovo.");

	}

	@Override
	public void emitirSom() {
		System.out.println("A galinha cacarejou");

	}

	public void dadosGalinha() {

		String string = null;

		if (this.getIdade() <= 1) {
			string = " ano";
		} else {
			string = " anos";
		}

		System.out.println("\n");
		System.out.println("***Novo animal cadastrado com sucesso!***");
		System.out.println("\n");
		System.out.println("A galinha tem " + this.getIdade() + string);
		System.out.println("O tamanho da galinha � " + this.getTamanho() + " cent�metros.");
		System.out.println("A cor da galinha � " + this.getCorDaPena() + ".");
	}

}
