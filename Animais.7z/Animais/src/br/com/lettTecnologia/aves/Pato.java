package br.com.lettTecnologia.aves;

import br.com.lettTecnologia.animais.VidaAnimal;

public class Pato extends Aves implements VidaAnimal {

	
	/**
	 * @author Adalberto Valadares
	 * 
	 *         Classe filha de Aves --> Animais, que herda os atributos de Animais
	 *         por meio de heran�a. possui os metodos botarOvo() do tipo void, voar() e
	 *         emitirSom(). Assim como o metodo dadosPato(), que realiza a
	 *         impressao dos dados do objeto,
	 * 
	 *         Dados impressos..: Idade, Tamanho, corDaPena, E o conteudo dos
	 *         metodos respectivos. *
	 * 
	 */
	
	
	public Pato() {
		super();

	}

	@Override
	public void botarOvo() {
		System.out.println("O pato botou um ovo.");

	}

	public void voar() {
		System.out.println("O pato est� voando a 2 mt de altura, altura m�xima de 5 mts.!");
	}

	@Override
	public void emitirSom() {

		System.out.println("O pato est� emitindo um grasnido.!");
	}

	public void dadosPato() {

		String string = null;

		if (this.getIdade() <= 1) {
			string = " ano";
		} else {
			string = " anos";
		}

		System.out.println("\n");
		System.out.println("***Novo animal cadastrado com sucesso!***");
		System.out.println("\n");
		System.out.println("O pato tem " + this.getIdade() + string);
		System.out.println("O tamanho da pato � " + this.getTamanho() + " cent�metros.");
		System.out.println("A cor da pato � " + this.getCorDaPena() + ".");
	}

}
