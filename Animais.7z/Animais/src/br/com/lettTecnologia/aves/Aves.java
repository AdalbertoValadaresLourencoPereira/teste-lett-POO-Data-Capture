package br.com.lettTecnologia.aves;

import br.com.lettTecnologia.animais.Animais;

public abstract class Aves extends Animais {

	private String corDaPena;

	public Aves() {
		super();
		this.corDaPena = corDaPena;
	}

	public String getCorDaPena() {
		return corDaPena;
	}

	public void setCorDaPena(String corDaPena) {
		this.corDaPena = corDaPena;
	}

	
	public abstract void botarOvo();



}
