# teste-lett-POO-Data-Capture
Repositorio com codigo fonte do teste java
Repositorio com o arquivo do teste de poo e construção de um crawler para.
No arquivo de projeto de codificação para o teste poo contem o codigo conforme solicitado, organizado em pacotes.
br.com.lettTecnologia.animais => comtem a interface VidaAnimal e superclasse Animal
br.com.lettTecnologia.aves => Contem super classe Aves, as subclasses Galinha e Pato
br.com.lettTecnologia.mamiferos => Contem super classe Mamiferos, as subclasses Morcego e Vaca
br.com.lettTecnologia.sistema => Classe com metodo main e classe com o codifição responsavel pela manipulação dos atributos dos objetos.

O projeto foi elborado com na diretriz enviado no documento PDF, foi divido a codificação das classes com base no processo de abstração,
visando empregar as tecnica de polimorfismo, herança, encapsulamento.

o Codigo está seguindo a seguinte estrtura.:Um pacote com classe Animal onde tem atributos comuns a todos os filos(aves e mamiferos)
deparadas dois pacotes, um contendo as classes apenas de mamiferos e outro apenas com aves.
e um quarto, com as classes responsaveis pela execução do sistemas. 

Para executar o projeto, basta realizar o download do mesmo, e importar no eclipse, netebeans, intellij, ou qualquer outra IDE, ou direto via
CMD. O codigo é executado pela classe TesteAnimaisFazenda, no pacote br.com.lettTecnologia.sistema.
