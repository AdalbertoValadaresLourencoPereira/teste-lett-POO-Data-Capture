import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;

public class WebCrawler {

	/**
	 * @author Adalberto Valadares Classe com a constru��o simples de um webCrawler,
	 *         que realiza a navega��o em um e-comerce para realizar a extra��o de
	 *         um produto escolhido e retorna a descri��o do mesmo.
	 * 
	 *         Foi utilizado a biblioteca Jsoup para a extra��o das informa��es via
	 *         seletores css.
	 * 
	 *         Temos duas extra��eos, uma tras diversos proutos e suas defini��es, o
	 *         outro, tras apenas as caracteristicas pertinentes de forma mais
	 *         simpl�ria.
	 * 
	 *         Para o teste foi utilizaado o site das lojas americanas, conforme
	 *         link no seletor.
	 * 
	 * @param args
	 * @throws IOException
	 */

	public static void main(String[] args) throws IOException {

		try {
/*			Document document = Jsoup.connect("https://www.americanas.com.br/produto/133774000/smart-tv-led-50-philips-50pug6513-78-ultra-hd-4k-com-conversor-digital-3-hdmi-2-usb-wi-fi-60hz-prata?DCSext.recom=RR_home_page.rr1-MultiItemPersonalizedViewCP&nm_origem=rec_home_page.rr1-MultiItemPersonalizedViewCP&nm_ranking_rec=1&pfm_carac=S%C3%B3%20as%20melhores%20ofertas&pfm_index=0&pfm_page=home&pfm_pos=home_page.rr1&pfm_type=vit_recommendation").get();
			// Tras informa��o mais detalhada.
			Elements elementos = document.select("h1,td"); 
		  
			for(Element el: elementos)
				System.out.println("\nProduto: "+el.text());
*/
			Document document = Jsoup.connect(
					"https://www.americanas.com.br/hotsite/atalho-eletronicos?chave=prf_hm_0_at_3_00_&pfm_carac=eletr%C3%B4nicos&pfm_page=home&pfm_pos=contenttop1&pfm_type=vit_spacey")
					.get();
			// realiza a extra��o mais superficial de varios produtos.
			Elements elementos2 = document.getElementsByClass("card-product-name");

			for (Element el : elementos2)
				System.out.println("\n Produto.: " + el.text() + el.toString());

		} catch (Exception e) {

			e.printStackTrace();
		}

	}

}
